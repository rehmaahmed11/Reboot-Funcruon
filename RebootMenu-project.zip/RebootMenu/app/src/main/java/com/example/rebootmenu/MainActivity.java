package com.example.rebootmenu;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);
        sv.addView(root);
        setContentView(sv);

        TextView t = new TextView(this);
        t.setText("Reboot Menu\n(root required, except Lock Screen)");
        t.setTextSize(20);
        root.addView(t);

        add(root, "Lock Screen", null);
        add(root, "Reboot", "reboot");
        add(root, "Soft Reboot (restart UI)", "killall system_server");
        add(root, "Reboot to Recovery", "reboot recovery");
        add(root, "Reboot to Bootloader", "reboot bootloader");
        add(root, "Reboot to Fastbootd", "reboot fastboot");
        add(root, "Reboot to Download Mode (Samsung)", "reboot download");
        add(root, "Reboot to Safe Mode", "setprop persist.sys.safemode 1 && reboot");
        add(root, "Power Off", "reboot -p");
    }

    private void add(LinearLayout root, final String label, final String cmd) {
        Button btn = new Button(this);
        btn.setText(label);
        btn.setAllCaps(false);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (cmd == null) { lockScreen(); return; }
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle(label).setMessage("Are you sure?")
                    .setPositiveButton("Yes", (d, w) -> runRoot(cmd))
                    .setNegativeButton("Cancel", null).show();
            }
        });
        root.addView(btn);
    }

    private void lockScreen() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, AdminReceiver.class);
        if (dpm.isAdminActive(admin)) {
            dpm.lockNow();
        } else {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
            i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed to lock the screen.");
            startActivity(i);
        }
    }

    private void runRoot(final String cmd) {
        new Thread(() -> {
            try {
                Process pr = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
                final int code = pr.waitFor();
                if (code != 0) toast("Command failed (code " + code + "). Is the device rooted?");
            } catch (Exception e) {
                toast("Root not available: " + e.getMessage());
            }
        }).start();
    }

    private void toast(final String s) {
        runOnUiThread(() -> Toast.makeText(this, s, Toast.LENGTH_LONG).show());
    }
}
